--EXEC [dbo].[Vehicle_PopUp] 1, '', '', 1, 10
ALTER PROCEDURE [dbo].[Vehicle_PopUp]
@IdCompanyBranch INT,
@IdOutbound VARCHAR(20),
@Search VARCHAR(200),
@PageIndex INT,
@PageSize INT
AS
SET NOCOUNT ON

--#Weighing
IF OBJECT_ID('tempdb.dbo.#Weighing') IS NOT NULL
BEGIN
  TRUNCATE TABLE dbo.#Weighing;
END
ELSE
BEGIN
	CREATE TABLE dbo.#Weighing(
		[Id] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY CLUSTERED,
		[IdCompany] [int] NOT NULL,
		[IdWeighing] [int] NOT NULL,
		[IdVehicle] [int] NOT NULL,
		)

	CREATE NONCLUSTERED INDEX [IX_TmpWeighing_IdVehicle] ON dbo.#Weighing
	(
		[IdCompany] ASC,
		[IdVehicle] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
END



INSERT INTO dbo.#Weighing (IdCompany, IdWeighing, IdVehicle)
SELECT 
we.IdCompany,
we.IdWeighing,
we.IdVehicle 
FROM dbo.Weighing we 
WHERE we.DeletedFlag = 0
AND (
	(we.IdStatus < 3 AND we.IdWeighingCycle = 1)
	OR
	(we.IdStatus < 2 AND we.IdWeighingCycle = 2)
)


--#Vehicle
IF OBJECT_ID('tempdb.dbo.#Vehicle') IS NOT NULL
BEGIN
  TRUNCATE TABLE dbo.#Vehicle;
END
ELSE
BEGIN
CREATE TABLE dbo.#Vehicle(
	[Id] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY CLUSTERED,
	[IdCompany] [int] NOT NULL,
	[IdVehicle] [int] NOT NULL,
	)
END

INSERT INTO dbo.#Vehicle
(IdCompany, IdVehicle)
SELECT
ve.IdCompany,
ve.IdVehicle
FROM dbo.Vehicle ve
INNER JOIN MasterTable tblm ON tblm.IdCompany = ve.IdCompany AND tblm.IdTable = 1 AND tblm.IdColumn = ve.IdStatus AND tblm.IdColumn > 0
LEFT JOIN VehicleType vety ON vety.IdCompany = ve.IdCompany AND vety.IdVehicleType = ve.IdVehicleConfiguration
LEFT JOIN Driver dr ON ve.IdCompany = dr.IdCompany AND ve.IdDriver = dr.IdDriver
LEFT JOIN Carrier tra ON tra.IdCompany = ve.IdCompany AND tra.IdCarrier = ve.IdCarrier
INNER JOIN MasterTable tire1 ON tire1.IdCompany = ve.IdCompany AND tire1.IdTable = 14 AND tire1.IdColumn = ve.IdTrailerType
WHERE NOT EXISTS (SELECT IdVehicle FROM dbo.#Weighing we 
			WHERE ve.IdCompany = we.IdCompany
				AND ve.IdVehicle = we.IdVehicle)
AND(
        ve.TruckNumber LIKE '%' + @Search + '%' OR ve.TruckInscription LIKE '%' + @Search + '%'
		OR ve.TruckBrand LIKE '%' + @Search + '%' OR ve.TruckModel LIKE '%' + @Search + '%' 
        OR ve.TrailerNumber LIKE '%' + @Search + '%' OR ve.TrailerInscription LIKE '%' + @Search + '%'
		OR dr.Driver LIKE '%' + @Search + '%' OR tra.Carrier LIKE '%' + @Search + '%' OR tire1.[Description] LIKE '%' + @Search + '%'
    )
AND ve.DeletedFlag = 0 
AND ve.IdCompanyBranch = @IdCompanyBranch
ORDER BY ve.TruckNumber ASC, ve.TrailerNumber ASC

DECLARE @TotalElements INT
SELECT @TotalElements = COUNT(1) FROM dbo.#Vehicle

SET NOCOUNT OFF
SELECT
ve.IdVehicle,
ve.RFID,
isnull(ve.IdVehicleConfiguration,0) IdVehicleConfiguration,
isnull(vety.VehicleType,'') VehicleType,
ve.TruckNumber,
ve.TruckLong,
ve.TruckWidth,
ve.TruckHigh,
ve.TruckInscription,
ve.TruckTare,
ve.TruckBrand,
ve.TruckModel,
ve.TruckMotor,
ve.IdTrailerType,
tire1.[Description] AS TrailerType,
ve.TrailerNumber,
ve.TrailerLong,
ve.TrailerWidth,
ve.TrailerHigh,
ve.TrailerInscription,
ve.TrailerTare,
ve.BonusFlag,
CONVERT(VARCHAR(10), ve.BonusExpirationDate, 120) AS BonusExpirationDate,
ve.BonusMaxGrossWeight,
ISNULL(ve.IdCarrier, 0) AS IdCarrier,
ISNULL(tra.Carrier, '') AS Carrier,
ve.IdDriver,
ISNULL(dr.Driver, '') AS Driver,
ISNULL(dr.LicenseNumber, '') AS LicenseNumber,
ISNULL((select top 1 rewe.TareWeight from ReWeighingWeight rewe 
		where rewe.IdCompany = ve.idcompany and rewe.IdVehicle = ve.IdVehicle
		order by IdReWeighingWeight desc),0) as LastTareReweight,
ve.IdStatus,
tblm.[Description] AS [Status],
@TotalElements AS TotalElement,
ISNULL(ve.TruckTareTolerance, 0) + ISNULL(ve.TrailerTareTolerance, 0) AS TareTolerance
FROM dbo.#Vehicle tmve
INNER JOIN dbo.Vehicle ve ON tmve.IdCompany = ve.IdCompany AND tmve.IdVehicle = ve.IdVehicle
INNER JOIN MasterTable tblm ON tblm.IdCompany = ve.IdCompany AND tblm.IdTable = 1 AND tblm.IdColumn = ve.IdStatus AND tblm.IdColumn > 0
LEFT JOIN VehicleType vety ON vety.IdCompany = ve.IdCompany AND vety.IdVehicleType = ve.IdVehicleConfiguration
LEFT JOIN Driver dr ON ve.IdCompany = dr.IdCompany AND ve.IdDriver = dr.IdDriver
LEFT JOIN Carrier tra ON tra.IdCompany = ve.IdCompany AND tra.IdCarrier = ve.IdCarrier
INNER JOIN MasterTable tire1 ON tire1.IdCompany = ve.IdCompany AND tire1.IdTable = 14 AND tire1.IdColumn = ve.IdTrailerType
ORDER BY ve.TruckNumber ASC, ve.TrailerNumber ASC
OFFSET @PageSize * (@PageIndex - 1) ROWS
FETCH NEXT @PageSize ROWS ONLY