Una vez instalado seguir los siguientes pasos:

1. Ir a la ubicación donde se instalo.
2. Identificar el archivo TrafiguraLecturaCardIdService.exe.config y abrirlo en un blog de notas.
3. Actualizar los valores del siguiente fragmento.
<appSettings>
    <add key="ipAddress" value="192.168.0.111"/> -- Una Ip dentro de Red asignado al lector de CardID
    <add key="puerto" value="33333"/> -- Puerto
    <add key="idCompanyBranch" value="1"/> -- Mantener el valor debido a que solo es para Perú 
    <add key="idBascule" value="1"/> -- Id de la Balanza de Repeso
    <add key="urlStatusWeight" value="http://localhost:4105/api/ReWeighing/TV_GetByBascule"/>  -- Reemplazar este fragmento http://localhost:4105/api por la url base de UAT (http://impalascale-uat.global.trafigura.com/scale-Api/api)
    <add key="urlValidPlate" value="http://localhost:4105/api/ReWeighing/ReWeighingVehicleCard_GetByCardId"/> -- Reemplazar este fragmento http://localhost:4105/api por la url base de UAT (http://impalascale-uat.global.trafigura.com/scale-Api/api)
  </appSettings>
4. Ir a servicios e identificar el nombre LectorCardId
5. Validar las credenciales o asignarle unas al servicio
6. Luego de iniciar esperar 1 minutos para que empiece a interactuar con el emulador de CardID